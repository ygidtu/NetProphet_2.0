.. _routines.help:

NumPy-specific help functions
=============================

.. currentmodule:: numpy

Finding help
------------

.. autosummary::
   :toctree: generated/

   lookfor


Reading help
------------

.. autosummary::
   :toctree: generated/

   info
   source
